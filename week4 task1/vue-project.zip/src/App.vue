<script>
export default {
  data() {
    return {
        name: 'Hello World'
      
    }
  }
}
</script>

<template>
  <span>{{ name}}</span>
</template>