<script>
import ButtonCounter from './ButtonCounter.vue'
  
export default {
  components: {
    ButtonCounter
  }
}
</script>

<template>
	<h1>Here are many child components!</h1>
	<ButtonCounter />  <br> <br>
	<ButtonCounter /> <br> <br> 
	<ButtonCounter /> <br> <br>
</template>